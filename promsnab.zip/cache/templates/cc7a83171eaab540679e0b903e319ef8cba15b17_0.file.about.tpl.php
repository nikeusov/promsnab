<?php
/* Smarty version 3.1.40, created on 2021-10-20 14:38:52
  from 'D:\OpenServer5.4.0\domains\promsnab\views\pages\home\about.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616fffcccadb45_61801428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc7a83171eaab540679e0b903e319ef8cba15b17' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\pages\\home\\about.tpl',
      1 => 1634729681,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616fffcccadb45_61801428 (Smarty_Internal_Template $_smarty_tpl) {
?><section class="about">
    <div class="about__container container">
        <div class="about__list">
            <div class="about__item">
                <div class="about__item-part about__item-left">
                    <img src="/img/about-1.jpg" alt="about" class="about__item-img">
                </div>
                <div class="about__item-part about__item-right">
                    <h2 class="about__title title-2 title-line">О предприятии</h2>
                    <p class="about__text section-text">
                        Наше предприятие работает с 2013 года. За эти годы мы приобрели прочные партнерские отношения с
                        компаниями не только в Краснодарском крае, но и в ряде других регионов юга России
                        (Ставропольском крае, республике Адыгее, республике Крым, городе Севастополе).
                    </p>
                    <p class="about__text section-text">
                        За годы своей деятельности завод неоднократно становился победителем конкурсов качества
                        продукции и участником ряда строительных выставок (YugBuild).
                    </p>
                </div>
            </div>
            <div class="about__item">
                <div class="about__item-part about__item-left">
                    <img src="/img/about-2.jpg" alt="about" class="about__item-img">
                </div>
                <div class="about__item-part about__item-right">
                    <h2 class="about__title title-2 title-line">Наше производство</h2>
                    <p class="about__text section-text">
                        На заводе производятся трубопроводы в пенополиуретановой изоляции, которые предназначаются для
                        воздушной и подземной бесканальной прокладки тепловых сетей.
                    </p>
                    <p class="about__text section-text">
                        В 2021 году произошло расширение производства. Была запущена новая производственная линия,
                        которая позволяет быстро и качественно выполнять крупные заказы и работать с трубами больших
                        диаметров (до 1220 мм).
                    </p>
                </div>
            </div>
        </div>
    </div>
</section><?php }
}
