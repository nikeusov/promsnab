<?php
/* Smarty version 3.1.40, created on 2021-10-20 12:52:25
  from 'D:\OpenServer5.4.0\domains\promsnab\views\blocks\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616fe6d9232156_31413750',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10b3009faffba999f8ab7d9c88551b0cfee715c0' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\blocks\\footer.tpl',
      1 => 1634722561,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616fe6d9232156_31413750 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="footer">
    <div class="footer__container container">
        <img src="/img/svg/logo.svg" alt="logo">
    </div>
</footer><?php }
}
