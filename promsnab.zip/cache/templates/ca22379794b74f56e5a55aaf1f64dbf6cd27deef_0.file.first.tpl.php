<?php
/* Smarty version 3.1.40, created on 2021-10-20 13:36:58
  from 'D:\OpenServer5.4.0\domains\promsnab\views\pages\home\first.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616ff14a8f41a4_94360960',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ca22379794b74f56e5a55aaf1f64dbf6cd27deef' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\pages\\home\\first.tpl',
      1 => 1634726181,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616ff14a8f41a4_94360960 (Smarty_Internal_Template $_smarty_tpl) {
?><section class="first">
    <div class="first__container container">
        <h1 class="first__title title-1">Производство труб в ППУ изоляции</h1>
        <p class="first__text">Комплектующие теплотрасс, фасонные изделия</p>
        <button class="first__button btn">Оставить заявку</button>
    </div>
</section><?php }
}
