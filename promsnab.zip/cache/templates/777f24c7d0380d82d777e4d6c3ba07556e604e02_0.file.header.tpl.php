<?php
/* Smarty version 3.1.40, created on 2021-10-20 12:52:25
  from 'D:\OpenServer5.4.0\domains\promsnab\views\blocks\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616fe6d90c8617_31864912',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '777f24c7d0380d82d777e4d6c3ba07556e604e02' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\blocks\\header.tpl',
      1 => 1634722506,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616fe6d90c8617_31864912 (Smarty_Internal_Template $_smarty_tpl) {
?><header class="header">
    <div class="header__container container">
        <img src="/img/svg/logo.svg" alt="logo">
    </div>
</header><?php }
}
