<?php
/* Smarty version 3.1.40, created on 2021-10-19 23:58:26
  from 'D:\OpenServer5.4.0\domains\promsnab\views\pages\home\benefits.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616f31727a4a01_74956959',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '360e55373a8554ea013ce7001fc64b0c175f3806' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\pages\\home\\benefits.tpl',
      1 => 1634676934,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616f31727a4a01_74956959 (Smarty_Internal_Template $_smarty_tpl) {
?><section class="benefits">
    <div class="benefits__container container">
        <div class="benefits__list">
            <div class="benefits__item">
                <div class="benefits__item-wr">
                    <div class="benefits__item-left">
                        <img class="benefits__item-img" src="/img/svg/benefits-mark.svg" alt="benefits icon">
                    </div>
                    <div class="benefits__item-center">
                        <h4 class="benefits__item-title title-4">
                            Доставка продукции до объекта монтажа
                        </h4>
                    </div>
                    <div class="benefits__item-right">
                        <div class="benefits__item-num">1</div>
                    </div>
                </div>
            </div>
            <div class="benefits__item">
                <div class="benefits__item-wr">
                    <div class="benefits__item-left">
                        <img class="benefits__item-img" src="/img/svg/benefits-car.svg" alt="benefits icon">
                    </div>
                    <div class="benefits__item-center">
                        <h4 class="benefits__item-title title-4">
                            Продукция производится в соответствии с требованиями ГОСТа 30732-2006
                        </h4>
                    </div>
                    <div class="benefits__item-right">
                        <div class="benefits__item-num">2</div>
                    </div>
                </div>
            </div>
            <div class="benefits__item">
                <div class="benefits__item-wr">
                    <div class="benefits__item-left">
                        <img class="benefits__item-img" src="/img/svg/benefits-title.svg" alt="benefits icon">
                    </div>
                    <div class="benefits__item-center">
                        <h4 class="benefits__item-title title-4">
                            Система менеджмента качества соответствует требованиям ГОСТ Р ИСО-2015 (ISO 9001:2015)
                        </h4>
                    </div>
                    <div class="benefits__item-right">
                        <div class="benefits__item-num">3</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php }
}
