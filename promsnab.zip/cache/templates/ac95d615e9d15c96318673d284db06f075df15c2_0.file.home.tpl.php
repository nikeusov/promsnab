<?php
/* Smarty version 3.1.40, created on 2021-10-19 17:40:06
  from 'D:\OpenServer5.4.0\domains\promsnab\views\pages\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616ed8c6cc33f3_50753222',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac95d615e9d15c96318673d284db06f075df15c2' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\pages\\home.tpl',
      1 => 1634399117,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./home/first.tpl' => 1,
    'file:./home/benefits.tpl' => 1,
    'file:./home/about.tpl' => 1,
  ),
),false)) {
function content_616ed8c6cc33f3_50753222 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_375548763616ed8c6c52088_27709752', 'main');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "page.tpl");
}
/* {block 'main'} */
class Block_375548763616ed8c6c52088_27709752 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'main' => 
  array (
    0 => 'Block_375548763616ed8c6c52088_27709752',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php $_smarty_tpl->_subTemplateRender("file:./home/first.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php $_smarty_tpl->_subTemplateRender("file:./home/benefits.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php $_smarty_tpl->_subTemplateRender("file:./home/about.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block 'main'} */
}
