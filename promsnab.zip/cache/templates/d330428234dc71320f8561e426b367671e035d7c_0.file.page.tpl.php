<?php
/* Smarty version 3.1.40, created on 2021-10-19 23:38:50
  from 'D:\OpenServer5.4.0\domains\promsnab\views\page.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_616f2cdac1c230_82752630',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd330428234dc71320f8561e426b367671e035d7c' => 
    array (
      0 => 'D:\\OpenServer5.4.0\\domains\\promsnab\\views\\page.tpl',
      1 => 1634675213,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:blocks/header.tpl' => 1,
    'file:blocks/footer.tpl' => 1,
    'file:modal/privacy.tpl' => 1,
  ),
),false)) {
function content_616f2cdac1c230_82752630 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <title><?php echo $_smarty_tpl->tpl_vars['meta']->value->title;?>
</title>

    <meta charset="UTF-8">

    <meta name="viewport" content="viewport-fit=cover, width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['meta']->value->description;?>
">
    <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['meta']->value->keywords;?>
">

    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['meta']->value->url;?>
">
    <meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['meta']->value->title;?>
">
    <meta property="og:description" content="<?php echo $_smarty_tpl->tpl_vars['meta']->value->description;?>
">
    <meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['meta']->value->image;?>
">

    <link rel="canonical" href="<?php echo $_smarty_tpl->tpl_vars['meta']->value->url;?>
">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="194x194" href="/favicon-194x194.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/android-chrome-192x192.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#0b1c56">
    <meta name="msapplication-TileColor" content="#2b5797">
    <meta name="msapplication-TileImage" content="/mstile-144x144.png">
    <meta name="theme-color" content="#0b1c56">

    <style>
        /*fonts*/
        @font-face {
            font-family: 'Gilroy';
            font-weight: 700;
            font-style: normal;
            font-display: swap;
            src: url('/fonts/Gilroy-Bold.woff2') format('woff2'),
            url('../fonts/Gilroy-Bold.woff') format('woff');
        }

        @font-face {
            font-family: 'Gilroy';
            font-weight: 900;
            font-style: normal;
            font-display: swap;
            src: url('/fonts/Gilroy-Black.woff2') format('woff2'),
            url('../fonts/Gilroy-Black.woff') format('woff');
        }

        @font-face {
            font-family: 'Gilroy-Heavy';
            font-weight: 900;
            font-style: normal;
            font-display: swap;
            src: url('/fonts/Gilroy-Heavy.woff2') format('woff2'),
            url('../fonts/Gilroy-Heavy.woff') format('woff');
        }

        @font-face {
            font-family: 'Manrope';
            font-weight: 400;
            font-style: normal;
            font-display: swap;
            src: url('/fonts/Manrope-Regular.woff2') format('woff2'),
            url('../fonts/Manrope-Regular.woff') format('woff');
        }
    </style>

    <?php echo $_smarty_tpl->tpl_vars['vendor_styles']->value;?>

    <?php echo $_smarty_tpl->tpl_vars['common_styles']->value;?>


    <?php if (!empty($_smarty_tpl->tpl_vars['page']->value->styles)) {?>
        <?php echo $_smarty_tpl->tpl_vars['page']->value->styles;?>

    <?php }?>

    <?php echo '<script'; ?>
 type="application/ld+json">
            {
                "@context": "http://schema.org",
                "@type": "Organization",
                "url": "<?php echo $_smarty_tpl->tpl_vars['meta']->value->url;?>
",
                "name": "<?php echo $_smarty_tpl->tpl_vars['meta']->value->title;?>
",
                "image": "<?php echo $_smarty_tpl->tpl_vars['meta']->value->image;?>
",
                "description": "<?php echo $_smarty_tpl->tpl_vars['meta']->value->description;?>
",
                "telephone": "<?php echo $_smarty_tpl->tpl_vars['phone']->value->title;?>
",
                "email": "<?php echo $_smarty_tpl->tpl_vars['email']->value->title;?>
",
                "address": {
                    "@type": "PostalAddress",
                    "addressLocality": "г. Анапа",
                    "streetAddress": "",
                    "postalCode": ""
                },
                "contactPoint": {
                    "@type": "ContactPoint",
                    "contactType": "sales",
                    "name": "Менеджер",
                    "telephone": "<?php echo $_smarty_tpl->tpl_vars['phone']->value->title;?>
"
                }
            }

    <?php echo '</script'; ?>
>

    <?php echo $_smarty_tpl->tpl_vars['inline_scripts']->value;?>


</head>
<body class="page page-<?php echo $_smarty_tpl->tpl_vars['page']->value->name;?>
">
<?php echo '<script'; ?>
>checkWebpSupport();<?php echo '</script'; ?>
>

<?php $_smarty_tpl->_subTemplateRender("file:blocks/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<main class="page__main page__main-<?php echo $_smarty_tpl->tpl_vars['page']->value->name;?>
">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_723626467616f2cdac12a95_54456204', 'main');
?>

</main>

<?php $_smarty_tpl->_subTemplateRender("file:blocks/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="intopModal__wrap">
    <?php $_smarty_tpl->_subTemplateRender("file:modal/privacy.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</div>

<?php echo $_smarty_tpl->tpl_vars['vendor_scripts']->value;?>

<?php echo $_smarty_tpl->tpl_vars['common_scripts']->value;?>

<?php if (!empty($_smarty_tpl->tpl_vars['model']->value->script)) {?>
    <?php echo $_smarty_tpl->tpl_vars['model']->value->script;?>

<?php }?>
</body>
</html><?php }
/* {block 'main'} */
class Block_723626467616f2cdac12a95_54456204 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'main' => 
  array (
    0 => 'Block_723626467616f2cdac12a95_54456204',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'main'} */
}
