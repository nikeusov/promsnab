// Общие стили для всех страниц
import "./common/global";
import "./common/modal";